export const metadata = {
  title: '{{projectName}}',
  description: 'Turborepo monorepo application',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
